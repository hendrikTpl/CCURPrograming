#input all the values first 
Wingcrd <- c(59, 55, 53.5, 55, 52.5, 57.5, 53, 55)
Tarsus <- c(22.3, 19.7, 20.8, 20.3, 20.8, 21.5, 20.6, 21.5)
Head <- c(31.2, 30.4, 30.6, 30.3, 30.3, 30.8, 32.5, NA)
Wt <- c(9.5, 13.8, 14.8, 15.2, 15.5, 15.6, 15.6, 15.7)
#then calculate the following values
paste("Mean for Wingcrd is",mean(Wingcrd))
paste("Mean for Tarsus is",mean(Tarsus))
paste("Mean for Head is",mean(Head, na.rm=TRUE))
paste("Mean for Wt is",mean(Wt))

paste("Median for Wingcrd is",median(Wingcrd))
paste("Median for Tarsus is",median(Tarsus))
paste("Median for Head is",median(Head, na.rm=TRUE))
paste("Median for Wt is",median(Wt))

paste("Min for Wingcrd is",min(Wingcrd))
paste("Min for Tarsus is",min(Tarsus))
paste("Min for Head is",min(Head, na.rm=TRUE))
paste("Min for Wt is",min(Wt))

paste("Max for Wingcrd is",max(Wingcrd))
paste("Max for Tarsus is",max(Tarsus))
paste("Max for Head is",max(Head, na.rm=TRUE))
paste("Max for Wt is",max(Wt))
