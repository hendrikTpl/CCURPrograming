#part2 for Lab 1 by 803410004 @ 2015 Spring R Programming Course at CCU CSIE 
#so far, we know that there are two ways to give a sequence of number to a set
#show the first way
num1<-1:100
#show the second way
num2<-seq(1,100)
#then we can check whether they are same
any(num1!=num2)
#finally, get the value ai*ai+...an*an
sum(num1*num1)