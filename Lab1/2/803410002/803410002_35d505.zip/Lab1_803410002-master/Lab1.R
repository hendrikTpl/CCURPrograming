x <- 123
print(x)
print("Zehn Zahme Ziegen ziehen zehn Zentner Zucker zum Zug!")
x = 1*1+2*2+3*3
x
x <- 1*1+2*2+3*3
x
print(sample(c(2,5,3), size=3, replace=TRUE))
print("Is this sufficient? :P")

