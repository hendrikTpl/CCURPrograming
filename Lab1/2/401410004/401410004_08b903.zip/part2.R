print (x <-sum((1:100)^2));
?InsectSprays
?seq
?mean
?swirl
?stats




