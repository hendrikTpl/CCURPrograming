print("By formula:")
print(100^3/3 + 100^2/2 + 100/6)
print("By direct calculation")
print(sum((1:100)^2))

?inspect
?seq
?mean
?stats
?swirl