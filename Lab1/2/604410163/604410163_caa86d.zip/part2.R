sum <- 0
for(i in 1:100)
{sum = sum+i*i}
print(sum)
