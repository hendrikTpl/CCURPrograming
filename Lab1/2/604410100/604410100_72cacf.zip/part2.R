x<-1:100
y<-sum(x*x)
print(y)

?mean