#Do some calculations (e.g. 1*1+2*2+3*3+�K+100*100)
ans <- sum(((1:100)^2))
print(ans)
#Learn some datasets (e.g. ?inspect)
??inspect
#Learn some function (e.g. ?seq, ?mean)
?seq
?mean
#Learn some package (e.g. ?stats,  ?swirl )
?stats
?swirl
#Try example in the help file
??help