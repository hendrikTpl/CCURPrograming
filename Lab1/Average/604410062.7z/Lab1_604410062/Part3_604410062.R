Analysis <- read.csv("C:/Users/Allyson/Desktop/part3.csv")
print(Analysis)
summary(Analysis)