x <- 1:100
y <- x*x
z <-sum(y)
z

?InsectSprays
?mean
?seq
?stats

Xmean <-mean(x)
Xmean

seq(0, 1, length.out = 11)